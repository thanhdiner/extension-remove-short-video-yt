DinKit v1.1.1 - HUONG DAN CAI DAT

Ban nay da build san. Khong can npm install hay npm run build de dung extension.

CAI TREN GOOGLE CHROME
1. Giai nen file ZIP vao mot thu muc co dinh tren may.
2. Mo chrome://extensions/ trong Chrome.
3. Bat Developer mode (Che do danh cho nha phat trien).
4. Bam Load unpacked (Tai tien ich da giai nen).
5. Chon thu muc DinKit co chua file manifest.json.
6. Ghim DinKit tren thanh cong cu va bam bieu tuong de su dung.

Neu dung trinh soan thao TXT hoac JSON tren may: vao Details (Chi tiet)
cua DinKit va bat Allow access to file URLs (Cho phep truy cap vao URL cua tep).
Giu nguyen thu muc da giai nen de Chrome tiep tuc nap extension.

TERMINAL / GIT / LUU TXT TRUC TIEP (TUY CHON, WINDOWS)
Cac tinh nang nay can native host rieng. Cac cong cu khac van dung duoc
khi chua cai host; editor van co the mo/luu bang hop thoai Chrome.

1. Cai Node.js ban LTS; cai them Git neu muon dung chuc nang Git.
2. Tai chrome://extensions/, sao chep ID cua DinKit tren may nay.
3. Mo PowerShell tai thu muc DinKit chua manifest.json, chay:

   npm ci --prefix editor/terminal-host
   powershell -ExecutionPolicy Bypass -File .\editor\terminal-host\install.ps1 -ExtensionId ID_DINKIT

   Thay ID_DINKIT bang ID vua sao chep, khong giu chu ID_DINKIT.
4. Reload DinKit tai chrome://extensions/ va mo lai tab editor.
5. Neu di chuyen thu muc hoac ID extension thay doi, chay lai lenh install.ps1.

Ban ZIP chi gom ma va tai nguyen ung dung; khong chua du lieu Chrome,
tai khoan 2FA, cau hinh proxy hay workspace ca nhan da luu tren may gui.
